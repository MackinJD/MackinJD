package application;

public class Item {
    private String name;

    public Item(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Item: " + name;
    }

	public int getPrice() {
		// TODO Auto-generated method stub
		return 0;
	}
}















































/*
package application;

public class Item {
    private String name;
    private int quantity;
    private double price;

    public Item(String name, int quantity, double price) {
        this.name = name;
        this.quantity = quantity;
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    // Method to add quantity to the item
    public void addItem(int quantity) {
        this.quantity += quantity;
    }

    @Override
    public String toString() {
        return "Item: " + name + ", Quantity: " + quantity + ", Price: " + price;
    }
}
*/























































/*
package application;

public class Item {
    private String name;
    private int quantity;
    private double price;

    public Item(String name, int quantity, double price) {
        this.name = name;
        this.quantity = quantity;
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return name + " (Quantity: " + quantity + ", Price: " + price + ")";
    }
}
*/
























































/*
package application;

public class Item {
    private String name;
    private int quantity;
    private double price;

    // No-argument constructor
    public Item() {
        this.name = "";
        this.quantity = 0;
        this.price = 0.0;
    }

    // Constructor with parameters
    public Item(String name, int quantity, double price) {
        this.name = name;
        this.quantity = quantity;
        this.price = price;
    }

    // Accessors and mutators
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    // toString for output formatting
    @Override
    public String toString() {
        return "Item Name: " + name + ", Quantity: " + quantity + ", Price: $" + price;
    }
}
*/
