
package application;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;



import java.util.ArrayList;
import java.util.List;

public class StoreApp extends Application {
    private List<Store> stores = new ArrayList<>();
    private List<Customers> customers = new ArrayList<>();
    private List<InventoryItem> inventory = new ArrayList<>();
    
    private static final double SALES_TAX = 0.07;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Store Management System");

        VBox menuVBox = new VBox();
        menuVBox.setPadding(new Insets(10));
        menuVBox.setSpacing(10);
        
      
        Button createStoreButton = new Button("Create a Store");
        Button viewInventoryButton = new Button("View Inventory");
        Button viewInventoryButton1 = new Button("Add Inventory");
        Button viewCustomersButton = new Button("View Customers");
        Button addCustomerButton = new Button("Add Customer");
        Button uploadInventoryButton = new Button("Upload Inventory");
        Button purchaseItemsButton = new Button("Purchase Items");
        Button uploadTestimonyButton = new Button("Upload Video Testimony");
        Button exitButton = new Button("Exit");

        createStoreButton.setOnAction(e -> createStore());
        viewInventoryButton.setOnAction(e -> viewInventory());
        viewInventoryButton1.setOnAction(e -> addInventory());
        viewCustomersButton.setOnAction(e -> viewCustomers());
        addCustomerButton.setOnAction(e -> addCustomer());
        uploadInventoryButton.setOnAction(e -> uploadInventory());
        purchaseItemsButton.setOnAction(e -> purchaseItems());
        uploadTestimonyButton.setOnAction(e -> uploadTestimony());
        exitButton.setOnAction(e -> primaryStage.close());

        menuVBox.getChildren().addAll(createStoreButton,viewInventoryButton, viewInventoryButton1, viewCustomersButton, addCustomerButton, uploadInventoryButton, purchaseItemsButton, uploadTestimonyButton, exitButton);

        Scene menuScene = new Scene(menuVBox, 400, 400);
        primaryStage.setScene(menuScene);
        primaryStage.show();
    }

    private void createStore() {
        Stage stage = new Stage();
        stage.setTitle("Create a Store");

        VBox vbox = new VBox();
        vbox.setPadding(new Insets(10));
        vbox.setSpacing(10);

        TextField storeTypeField = new TextField();
        storeTypeField.setPromptText("Store Type");
        TextField storeNameField = new TextField();
        storeNameField.setPromptText("Store Name");
        TextField storeLocationField = new TextField();
        storeLocationField.setPromptText("Store Location");

        Button addButton = new Button("Add Store");
        addButton.setOnAction(event -> {
            String storeType = storeTypeField.getText();
            String storeName = storeNameField.getText();
            String storeLocation = storeLocationField.getText();
            stores.add(new Store(storeType, storeName, storeLocation));
            stage.close();
        });

        vbox.getChildren().addAll(new Label("Store Type:"), storeTypeField, new Label("Store Name:"), storeNameField, new Label("Store Location:"), storeLocationField, addButton);

        Scene scene = new Scene(vbox, 300, 300);
        stage.setScene(scene);
        stage.show();
    }

    private void viewInventory() {
        Stage stage = new Stage();
        stage.setTitle("Inventory");

        if (stores.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Error", "No stores available.");
            return;
        }

        VBox vbox = new VBox();
        vbox.setPadding(new Insets(10));
        vbox.setSpacing(10);

        ComboBox<Store> storeComboBox = new ComboBox<>();
        storeComboBox.getItems().addAll(stores);
        
        TextArea textArea = new TextArea();
        textArea.setEditable(false);

        Button viewButton = new Button("View Inventory");
        viewButton.setOnAction(event -> {
            Store selectedStore = storeComboBox.getSelectionModel().getSelectedItem();
            if (selectedStore != null) {
            	StringBuilder sb = new StringBuilder();
            	for (Item item : selectedStore.getInventory()) {
            		sb.append(item.toString()).append("\n");
            	}
            	textArea.setText(sb.toString());

        vbox.getChildren().addAll(new Label("Select Store:"), storeComboBox, viewButton);

        Scene scene = new Scene(vbox, 300, 300);
        stage.setScene(scene);
        stage.show();
            }
 

    private void viewCustomers() {
        Stage stage = new Stage();
        stage.setTitle("View Customers");

        VBox vbox = new VBox();
        vbox.setPadding(new Insets(10));
        vbox.setSpacing(10);

        TextArea textArea = new TextArea();
        textArea.setEditable(false);

        StringBuilder sb = new StringBuilder();
        for (Customers customer : customers) {
            sb.append(customer.toString()).append("\n");
        }
        textArea.setText(sb.toString());

        vbox.getChildren().addAll(new Label("Customers:"), textArea);

        Scene scene = new Scene(vbox, 300, 300);
        stage.setScene(scene);
        stage.show();
    }

    private void addCustomer() {
        Stage stage = new Stage();
        stage.setTitle("Add Customer");

        VBox vbox = new VBox();
        vbox.setPadding(new Insets(10));
        vbox.setSpacing(10);

        TextField nameField = new TextField();
        nameField.setPromptText("Customer Name");
        TextField addressField = new TextField();
        addressField.setPromptText("Customer Address");
        TextField phoneField = new TextField();
        phoneField.setPromptText("Customer Phone");
        TextField emailField = new TextField();
        emailField.setPromptText("Customer Email");

        Button addButton = new Button("Add Customer");
        addButton.setOnAction(event -> {
            String name = nameField.getText();
            String address = addressField.getText();
            String phone = phoneField.getText();
            String email = emailField.getText();
            customers.add(new Customers(name, address, phone, email));
            stage.close();
        });

        vbox.getChildren().addAll(new Label("Customer Name:"), nameField, new Label("Customer Address:"), addressField, new Label("Customer Phone:"), phoneField, new Label("Customer Email:"), emailField, addButton);

        Scene scene = new Scene(vbox, 300, 300);
        stage.setScene(scene);
        stage.show();
    }

    private void uploadInventory() {
        Stage stage = new Stage();
        stage.setTitle("Upload Inventory");

        if (stores.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Error", "No stores available.");
            return;
        }

        VBox vbox = new VBox();
        vbox.setPadding(new Insets(10));
        vbox.setSpacing(10);

        ComboBox<Store> storeComboBox = new ComboBox<>();
        storeComboBox.getItems().addAll(stores);

        TextField itemNameField = new TextField();
        itemNameField.setPromptText("Item Name");
        TextField priceField = new TextField();
        priceField.setPromptText("Price");

        Button addButton = new Button("Add Item");
        addButton.setOnAction(event -> {
            Store selectedStore = storeComboBox.getSelectionModel().getSelectedItem();
            if (selectedStore != null) {
                String itemName = itemNameField.getText();
                double price = Double.parseDouble(priceField.getText());
                selectedStore.addItem(new Item(itemName));
                showAlert(Alert.AlertType.INFORMATION, "Success", "Item added to inventory.");
            }
            stage.close();
        });

        vbox.getChildren().addAll(new Label("Select Store:"), storeComboBox, new Label("Item Name:"), itemNameField, new Label("Price:"), priceField, addButton);

        Scene scene = new Scene(vbox, 300, 300);
        stage.setScene(scene);
        stage.show();
    }
    private void addInventory() { 
    	Stage stage = new Stage(); stage.setTitle("Add Inventory"); 

    	VBox vbox = new VBox(); 
    	vbox.setPadding(new Insets(10)); 
    	vbox.setSpacing(10); 

    	TextField itemNameField = new TextField(); 
    	itemNameField.setPromptText("Item Name"); 
    	TextField itemPriceField = new TextField(); 
    	itemPriceField.setPromptText("Item Price"); 

    	Button addButton = new Button("Add Item"); 
    	addButton.setOnAction(event -> { 
    		String itemName = itemNameField.getText(); 
    		double itemPrice = Double.parseDouble(itemPriceField.getText()); 
    		
    		//Inventory.put(itemName, itemPrice); 
    		showAlert(Alert.AlertType.INFORMATION, "Success", "Added " + itemName + " at $" + itemPrice + " each."); 
    		
    		stage.close(); 
    	}); 
    	vbox.getChildren().addAll(new Label("Item Name:"), itemNameField, new Label("Item Price:"), itemPriceField, addButton); 

    	Scene scene = new Scene(vbox, 300, 300); 
    	stage.setScene(scene); 
    	stage.show(); 
    }

    private void showAlert(AlertType error, String string, String string2) {
    	Alert alert = new Alert(error);
    	alert.setTitle(string);
    	alert.setContentText(string2);
    	alert.showAndWait();
    	
		// TODO Auto-generated method stub
		
	}

	private void purchaseItems() {
        Stage stage = new Stage();
        stage.setTitle("Purchase Items");

        if (stores.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Error", "No stores available.");
            return;
        }

        VBox vbox = new VBox();
        vbox.setPadding(new Insets(10));
        vbox.setSpacing(10);

        ComboBox<Store> storeComboBox = new ComboBox<>();
        storeComboBox.getItems().addAll(stores);

        TextField customerNameField = new TextField();
        customerNameField.setPromptText("Customer Name");
        TextField itemNameField = new TextField();
        itemNameField.setPromptText("Item Name");
        

        TextArea receiptArea = new TextArea();
        receiptArea.setEditable(false);

        Button purchaseButton = new Button("Purchase");
        purchaseButton.setOnAction(event -> {
            Store selectedStore = storeComboBox.getSelectionModel().getSelectedItem();
            String customerName = customerNameField.getText();
            String itemName = itemNameField.getText();
           

            if (selectedStore == null || customerName.isEmpty() || itemName.isEmpty())
                showAlert(Alert.AlertType.ERROR, "Error", "Please fill in all fields.");
                return;
            });

            for (Customers customer : customers) {
                if (customer.getName().equalsIgnoreCase(customer)) {
                    for (Item item : selectedStore.getInventory()) {
                        if (item.getName().equalsIgnoreCase(item)); //&& item.getQuantity() >= quantity) {
                            double totalPrice = item.getPrice();
                            totalPrice += totalPrice * SALES_TAX;
                            totalPrice = applyDiscounts(totalPrice);
                    }
                }
            }
        });

        vbox.getChildren().addAll(new Label("Select Store:"), storeComboBox, new Label("Customer Name:"), customerNameField, new Label("Item Name:"), itemNameField, new Label("Quantity:"), quantityField, purchaseButton, receiptArea);

        Scene scene = new Scene(vbox, 400, 400);
        stage.setScene(scene);
        stage.show();

	
    private double applyDiscounts(double totalPrice) {
        if (totalPrice > 200) {
            return totalPrice * 0.85; // 15% discount
        } else if (totalPrice > 100) {
            return totalPrice * 0.90; // 10% discount
        } else if (totalPrice > 50) {
            return totalPrice * 0.95; // 5% discount
        }
        return totalPrice;
    }

    private void uploadTestimony() {
        Stage stage = new Stage();
        stage.setTitle("Upload Video Testimony");

        VBox vbox = new VBox();
        vbox.setPadding(new Insets(10));
        vbox.setSpacing(10);

        TextField customerNameField = new TextField();
        customerNameField.setPromptText("Customer Name");
        TextField videoURLField = new TextField();
        videoURLField.setPromptText("Video URL");
        TextArea videoDescriptionArea = new TextArea();
        videoDescriptionArea.setPromptText("Video Description");

        Button uploadButton = new Button("Upload");
        uploadButton.setOnAction(event -> {
            String customerName = customerNameField.getText();
            String videoURL = videoURLField.getText();
            String videoDescription = videoDescriptionArea.getText();

            if (customerName.isEmpty() || (videoURL.isEmpty() && videoDescription.isEmpty())) {
                showAlert(Alert.AlertType.ERROR, "Error", "Please provide the customer name and either a video URL or a description.");
                return;
            }

            for (Customers customer : customers) {
                if (customer.getName().equalsIgnoreCase(customerName)) {
                    // Simulate uploading the video testimony
                    showAlert(Alert.AlertType.INFORMATION, "Upload Successful", "Video testimony uploaded successfully.");
                    stage.close();
                    return;
                }
            }
            showAlert(Alert.AlertType.ERROR, "Error", "Customer not found.");
        });

        vbox.getChildren().addAll(new Label("Customer Name:"), customerNameField, new Label("Video URL:"), videoURLField, new Label("Video Description:"), videoDescriptionArea, uploadButton);

        Scene scene = new Scene(vbox, 400, 300);
        stage.setScene(scene);
        stage.show();
    }

    }























































































































