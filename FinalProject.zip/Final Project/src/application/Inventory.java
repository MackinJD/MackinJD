package application;

import java.util.ArrayList;
import java.util.List;

public class Inventory {
    private List<InventoryItem> items = new ArrayList<>();

    public void addItem(String itemName) {
        for (InventoryItem item : items) {
            if (item.getName().equals(itemName)) {
                return;
            }
        }
        items.add(new InventoryItem(itemName));
    }

    public String viewItems() {
        StringBuilder inventoryList = new StringBuilder();
        for (InventoryItem item : items) {
            inventoryList.append(item).append("\n");
        }
        return inventoryList.toString();
    }

    public List<InventoryItem> getInventory() {
        return new ArrayList<>(items);
    }
}

	//public static Object get(String item) {
		// TODO Auto-generated method stub
		//return null;
	


class InventoryItem {
    private String name;
	public String price;

    public InventoryItem(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return  name ;
    }
}




















































/*
package application;

import java.util.ArrayList;
import java.util.List;

public class Inventory {
    private List<InventoryItem> items = new ArrayList<>();

    public void addItem(String itemName, int quantity) {
        for (InventoryItem item : items) {
            if (item.getName().equals(itemName)) {
                item.addQuantity(quantity);
                return;
            }
        }
        items.add(new InventoryItem(itemName, quantity));
    }

    public String viewItems() {
        StringBuilder inventoryList = new StringBuilder();
        for (InventoryItem item : items) {
            inventoryList.append(item).append("\n");
        }
        return inventoryList.toString();
    }

    public boolean hasItem(String itemName, int quantity) {
        for (InventoryItem item : items) {
            if (item.getName().equals(itemName) && item.getQuantity() >= quantity) {
                return true;
            }
        }
        return false;
    }

    public void reduceItemQuantity(String itemName, int quantity) {
        for (InventoryItem item : items) {
            if (item.getName().equals(itemName)) {
                item.reduceQuantity(quantity);
                return;
            }
        }
    }

    // Method to get the inventory list
    public List<InventoryItem> getInventory() {
        return new ArrayList<>(items);
    }
}

class InventoryItem {
    private String name;
    private int quantity;

    public InventoryItem(String name, int quantity) {
        this.name = name;
        this.quantity = quantity;
    }

    public String getName() {
        return name;
    }

    public int getQuantity() {
        return quantity;
    }

    public void addQuantity(int quantity) {
        this.quantity += quantity;
    }

    public void reduceQuantity(int quantity) {
        this.quantity -= quantity;
    }

    @Override
    public String toString() {
        return "Item: " + name + ", Quantity: " + quantity;
    }
}
*/













































/*
package application;

import java.util.ArrayList;
import java.util.List;

public class Inventory {
    private List<InventoryItem> items = new ArrayList<>();

    public void addItem(String itemName, int quantity) {
        for (InventoryItem item : items) {
            if (item.getName().equals(itemName)) {
                item.addQuantity(quantity);
                return;
            }
        }
        items.add(new InventoryItem(itemName, quantity));
    }

    public String viewItems() {
        StringBuilder inventoryList = new StringBuilder();
        for (InventoryItem item : items) {
            inventoryList.append(item).append("\n");
        }
        return inventoryList.toString();
    }

    public boolean hasItem(String itemName, int quantity) {
        for (InventoryItem item : items) {
            if (item.getName().equals(itemName) && item.getQuantity() >= quantity) {
                return true;
            }
        }
        return false;
    }

    public void reduceItemQuantity(String itemName, int quantity) {
        for (InventoryItem item : items) {
            if (item.getName().equals(itemName)) {
                item.reduceQuantity(quantity);
                return;
            }
        }
    }
}

class InventoryItem {
    private String name;
    private int quantity;

    public InventoryItem(String name, int quantity) {
        this.name = name;
        this.quantity = quantity;
    }

    public String getName() {
        return name;
    }

    public int getQuantity() {
        return quantity;
    }

    public void addQuantity(int quantity) {
        this.quantity += quantity;
    }

    public void reduceQuantity(int quantity) {
        this.quantity -= quantity;
    }

    @Override
    public String toString() {
        return "Item: " + name + ", Quantity: " + quantity;
    }
}
*/