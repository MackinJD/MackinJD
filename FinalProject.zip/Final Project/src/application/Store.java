package application;

import java.util.ArrayList;
import java.util.List;

public class Store {
    private String storeType;
    private String storeName;
    private String storeLocation;
    private List<Item> inventory;

    public Store() {
        this.storeType = "Misc";
        this.storeName = "Generic Store";
        this.storeLocation = "United States";
        
    }

    public Store(String storeType, String storeName, String storeLocation) {
        this.storeType = storeType;
        this.storeName = storeName;
        this.storeLocation = storeLocation;
        
    }

    public String getStoreType() {
        return storeType;
    }

    public void setStoreType(String storeType) {
        this.storeType = storeType;
    }

    public String getStoreName() {
        return storeName;
    }

    public void setStoreName(String storeName) {
        this.storeName = storeName;
    }

    public String getStoreLocation() {
        return storeLocation;
    }

    public void setStoreLocation(String storeLocation) {
        this.storeLocation = storeLocation;
    }

    public List<Item> getInventory() {
        return inventory;
    }

    public void addItem(Item item) {
        inventory.add(item);
    }

    @Override
    public String toString() {
        return  storeType + ","  + storeName + ","  + storeLocation;
    }
}





















































/*
package application;

public class Store {
	private String storeType;
	private String storeName;
	private String storeLocation;
	

	
	public Store() {
		super();
		this.storeType = "Misc";
		this.storeName = "Generic Store";
		this.storeLocation = "United States";
	}
	public Store(String storeType, String storeName, String storeLocation) {
		super();
		this.storeType = storeType;
		this.storeName = storeName;
		this.storeLocation = storeLocation;
	}
	public String getStoreType() {
		return storeType;
	}
	public void setStoreType(String storeType) {
		this.storeType = storeType;
	}
	public String getStoreName() {
		return storeName;
	}
	public void setStoreName(String storeName) {
		this.storeName = storeName;
	}
	public String getStoreLocation() {
		return storeLocation;
	}
	public void setStoreLocation(String storeLocation) {
		this.storeLocation = storeLocation;
	}
	
	
	@Override
	public String toString() {
		return "Store [storeType=" + storeType + ", storeName=" + storeName + ", storeLocation=" + storeLocation + "]";
	}
	public Item[] getInventory() {
		// TODO Auto-generated method stub
		return null;
	}

}
*/
